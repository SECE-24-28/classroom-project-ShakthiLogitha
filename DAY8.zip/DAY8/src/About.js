const About=()=>
{
    return(
        <>
        <h1>this is about da!</h1></>
    )
}
export default About;