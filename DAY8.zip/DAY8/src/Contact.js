const Contact=()=>
{
    return(
        <>
        <h1>this is contact da!</h1></>
    )
}
export default Contact;