const Home=()=>
{
    return(
        <>
        <h1>this is Home da!</h1></>
    )
}
export default Home;