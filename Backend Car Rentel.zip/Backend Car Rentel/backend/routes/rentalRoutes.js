const express = require('express');
const Rental = require('../models/Rental');
const Car = require('../models/Car');
const { protect } = require('../middleware/authMiddleware');
const router = express.Router();

// Rent a car
router.post('/', protect, async (req, res) => {
  try {
    console.log('Rental request body:', req.body);
    const { car, customerName, startDate, endDate } = req.body;

    if (!car) {
      return res.status(400).json({ message: 'Car ID is required' });
    }

    console.log('Looking for car with ID:', car);
    const carExists = await Car.findById(car);
    console.log('Car found:', carExists);
    
    if (!carExists) {
      return res.status(404).json({ 
        message: 'Car not found',
        carId: car,
        debug: 'Check if car ID is valid MongoDB ObjectId'
      });
    }

    if (!carExists.available) {
      return res.status(400).json({ message: 'Car is not available' });
    }

    const rental = await Rental.create({ car, customerName, startDate, endDate });
    await Car.findByIdAndUpdate(car, { available: false });

    res.status(201).json(rental);
  } catch (error) {
    console.log('Rental error:', error);
    res.status(400).json({ message: error.message });
  }
});

// Get all rentals
router.get('/', protect, async (req, res) => {
  try {
    const rentals = await Rental.find({}).populate('car');
    res.json(rentals);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Return car
router.put('/return/:id', protect, async (req, res) => {
  try {
    const rental = await Rental.findById(req.params.id);
    if (!rental) {
      return res.status(404).json({ message: 'Rental not found' });
    }

    if (rental.returned) {
      return res.status(400).json({ message: 'Car already returned' });
    }

    rental.returned = true;
    await rental.save();
    await Car.findByIdAndUpdate(rental.car, { available: true });

    res.json(rental);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;