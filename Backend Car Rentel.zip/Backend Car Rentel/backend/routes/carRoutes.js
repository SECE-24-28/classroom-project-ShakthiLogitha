const express = require('express');
const Car = require('../models/Car');
const { protect } = require('../middleware/authMiddleware');
const router = express.Router();

// Add car
router.post('/', protect, async (req, res) => {
  try {
    console.log('Request body:', req.body); // Debug log
    
    // Handle different field name formats
    const brand = req.body.Brand || req.body.brand;
    const model = req.body.Model || req.body.model;
    const year = req.body.Year || req.body.year;
    const pricePerDay = req.body['Price Per Day'] || req.body.pricePerDay || req.body.price;
    
    if (!brand || !model || !year || !pricePerDay) {
      return res.status(400).json({ 
        message: 'All fields are required: Brand, Model, Year, Price Per Day',
        received: req.body
      });
    }
    
    const car = await Car.create({ 
      carName: `${brand} ${model} ${year}`,
      brand: brand, 
      model: model, 
      pricePerDay: Number(pricePerDay)
    });
    res.status(201).json(car);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get all cars
router.get('/', protect, async (req, res) => {
  try {
    const cars = await Car.find({});
    res.json(cars);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Update car
router.put('/:id', protect, async (req, res) => {
  try {
    const car = await Car.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!car) {
      return res.status(404).json({ message: 'Car not found' });
    }
    res.json(car);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete car
router.delete('/:id', protect, async (req, res) => {
  try {
    const car = await Car.findByIdAndDelete(req.params.id);
    if (!car) {
      return res.status(404).json({ message: 'Car not found' });
    }
    res.json({ message: 'Car deleted successfully' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;